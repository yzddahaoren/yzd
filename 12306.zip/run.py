# -*- coding=utf-8 -*-
from init import login, select_ticket_info


def run():
    # login.main()
    select_ticket_info.select().main()


if __name__ == '__main__':
    run()