#!/bin/sh
# Database info
DB_NAME="radius"
DB_USER="root"
DB_PASS="0p0o0i0900"
# Others vars
BIN_DIR="/usr/bin"
BCK_DIR="/usr/mysys/dbback/dbfile"
DATE=`date +%F`
# TODO
$BIN_DIR/mysqldump -u$DB_USER -p$DB_PASS $DB_NAME | gzip >$BCK_DIR/db_hy_$DATE.sql.gz
